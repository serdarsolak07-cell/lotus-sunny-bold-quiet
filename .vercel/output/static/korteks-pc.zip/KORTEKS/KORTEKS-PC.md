# KORTEKS — PC otokurulum

Yapımcı: SERDAR KAPTAN. Çekirdek bellek; silinmez.

## Windows
1. `korteks-pc.zip` dosyasını açın.
2. `KUR.bat` dosyasına çift tıklayın.
3. Node yoksa betik LTS kurmayı dener. Tarayıcı kendiliğinden açılır.

## Mac / Linux
```
chmod +x KUR.sh
./KUR.sh
```

## Docker
```
docker compose up --build
```
Tarayıcı: `http://127.0.0.1:8080`

## Not
- Node 22 gerekir.
- Atlas, katalog, yol, test çevrimdışı çalışır.
- Sohbet için isteğe bağlı: `XAI_API_KEY` ortam değişkeni.
- `npm run dev` 8080 portunu kullanır.
