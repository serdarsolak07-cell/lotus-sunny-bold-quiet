#!/usr/bin/env bash
# KORTEKS — Mac/Linux otokurulum. Yapımcı: SERDAR KAPTAN
set -euo pipefail
cd "$(dirname "$0")"

echo "KORTEKS otokurulum"
echo "Yapımcı: SERDAR KAPTAN"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js yok."
  if command -v brew >/dev/null 2>&1; then
    echo "Homebrew ile Node 22 kuruluyor..."
    brew install node@22 || brew install node
  else
    echo "https://nodejs.org adresinden Node 22 kurun, sonra ./KUR.sh çalıştırın."
    command -v xdg-open >/dev/null && xdg-open "https://nodejs.org/en/download" || true
    command -v open >/dev/null && open "https://nodejs.org/en/download" || true
    exit 1
  fi
fi

echo "Node: $(node -v)"
if [ ! -d node_modules ]; then
  echo "Paketler kuruluyor (birkaç dakika)..."
  npm install
fi

url="http://127.0.0.1:8080"
( sleep 3
  command -v open >/dev/null && open "$url" && exit 0
  command -v xdg-open >/dev/null && xdg-open "$url" && exit 0
) >/dev/null 2>&1 &

echo "Sunucu açılıyor."
npm run dev
