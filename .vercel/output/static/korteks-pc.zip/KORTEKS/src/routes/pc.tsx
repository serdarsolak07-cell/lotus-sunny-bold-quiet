import { createFileRoute } from "@tanstack/react-router";
import { CORE } from "@/data/core";
import { makerName } from "@/lib/core-seal";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/pc")({ component: PcKur });

function PcKur() {
  const name = makerName(CORE.maker);
  return (
    <main className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <p className="font-mono text-xs text-accent">PC · OTOKURULUM</p>
      <h1 className="mt-3 font-display text-4xl leading-tight sm:text-5xl">
        Bu siteyi bilgisayarda çalıştır.
      </h1>
      <p className="mt-5 text-[17px] leading-relaxed text-muted">
        Zip’i indir, aç, kurulum dosyasına bas. Node yoksa betik kurmayı dener.
        Tarayıcı kendiliğinden açılır. Yapımcı {name}.
      </p>

      <div className="mt-8">
        <Button asChild>
          <a href="/korteks-pc.zip" download>
            korteks-pc.zip indir
          </a>
        </Button>
      </div>

      <ol className="mt-12 grid gap-4">
        <li className="rounded-xl bg-surface p-5 shadow-[0_0_0_1px_var(--color-line)]">
          <p className="font-mono text-[11px] text-subtle">1 · WINDOWS</p>
          <p className="mt-2 text-sm leading-relaxed">
            Zip’i sağ tıkla, ayıkla. Klasörde <span className="text-fg">KUR.bat</span>{" "}
            dosyasına çift tıkla. İlk seferde paket indirme birkaç dakika sürer.
          </p>
        </li>
        <li className="rounded-xl bg-surface p-5 shadow-[0_0_0_1px_var(--color-line)]">
          <p className="font-mono text-[11px] text-subtle">2 · MAC / LINUX</p>
          <p className="mt-2 text-sm leading-relaxed">
            Zip’i aç. Terminalde klasöre gir.{" "}
            <span className="text-fg">chmod +x KUR.sh && ./KUR.sh</span>
          </p>
        </li>
        <li className="rounded-xl bg-surface p-5 shadow-[0_0_0_1px_var(--color-line)]">
          <p className="font-mono text-[11px] text-subtle">3 · DOCKER</p>
          <p className="mt-2 text-sm leading-relaxed">
            Aynı klasörde <span className="text-fg">docker compose up --build</span>.
            Docker yoksa 1 veya 2 yeter.
          </p>
        </li>
      </ol>

      <aside className="mt-10 rounded-xl bg-raised p-5 shadow-[0_0_0_1px_var(--color-line)]">
        <p className="font-mono text-[11px] tracking-[0.14em] text-accent">NOT</p>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          Node 22. Atlas çevrimdışı çalışır. Sohbet için isteğe bağlı xAI anahtarı.
          Çekirdek: {CORE.role} {name}.
        </p>
      </aside>
    </main>
  );
}
